<p>
    <?php
    _e('This field type is not supported. E-mail support@wpallimport.com with the details of the custom ACF field you are trying to import to, as well as a link to download the plugin to install to add this field type to ACF, and we will investigate the possiblity ot including support for it in the ACF add-on.', 'wp_all_import_acf_add_on');
    ?>
</p>