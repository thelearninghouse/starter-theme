<?php


interface CdataStrategy
{
    public function should_cdata_be_applied($field, $hasSnippets = false);
}