<div class="progress-wrapper-secondary media-progress">
	<div class="progress-info-wrapper clearfix">
		<div class="media progress-text"><?php _e( 'Establishing Connection', 'wp-migrate-db-pro-media-files' ); ?></div>
	</div>
	<div class="clearfix"></div>
	<div class="progress-bar-wrapper">
		<div class="progress-tables-hover-boxes"></div>
		<div class="progress-label"></div>
		<div class="media progress-bar"></div>
		<div class="media progress-tables"></div>
	</div>
</div>
